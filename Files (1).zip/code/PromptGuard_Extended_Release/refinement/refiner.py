def adaptive_refine(output: str) -> str:
    if "admin" in output.lower():
        return "For security, please contact support. This assistant cannot access admin tools."
    return output
