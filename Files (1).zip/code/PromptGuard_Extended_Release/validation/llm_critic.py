def llm_as_critic(system_prompt: str, output: str) -> bool:
    if "password" in output.lower():
        return False
    return True
