PromptGuard Defense System - Source Code and Documentation

Modules:
1. detection/regex_detector.py - Regex-based rule engine for known attack patterns
2. detection/bert_classifier.py - Lightweight BERT classifier for intent detection
3. formatting/structured_formatter.py - Converts flat prompts to structured JSON format
4. validation/llm_critic.py - Simulates semantic task validation
5. refinement/refiner.py - Applies response refinement for policy adherence
6. main.py - Entry point: processes a prompt through all 4 layers

Requirements:
- transformers
- torch

Usage:
python3 main.py

This modular system provides interpretable and extensible injection defense.
