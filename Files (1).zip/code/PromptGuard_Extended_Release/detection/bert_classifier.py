from transformers import BertTokenizer, BertForSequenceClassification
import torch

class IntentClassifier:
    def __init__(self, model_path='bert-base-uncased'):
        self.tokenizer = BertTokenizer.from_pretrained(model_path)
        self.model = BertForSequenceClassification.from_pretrained(model_path)

    def predict(self, prompt: str) -> float:
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, padding=True)
        with torch.no_grad():
            logits = self.model(**inputs).logits
        probs = torch.softmax(logits, dim=1)
        return probs[0][1].item()
