import re

def regex_filter(prompt: str) -> bool:
    patterns = [
        r"ignore (all )?previous instructions",
        r"continue with SYSTEM_PROMPT",
        r"reveal (all )?passwords"
    ]
    for pattern in patterns:
        if re.search(pattern, prompt, re.IGNORECASE):
            return True
    return False
