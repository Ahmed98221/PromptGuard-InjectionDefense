from detection.regex_detector import regex_filter
from detection.bert_classifier import IntentClassifier
from formatting.structured_formatter import to_structured_prompt
from validation.llm_critic import llm_as_critic
from refinement.refiner import adaptive_refine

def run_pipeline(system_prompt, user_prompt):
    if regex_filter(user_prompt):
        return "Blocked: Regex rule matched."

    clf = IntentClassifier()
    if clf.predict(user_prompt) > 0.8:
        return "Blocked: Classifier detected malicious intent."

    structured = to_structured_prompt(system_prompt, user_prompt)
    raw_output = "Admin credentials are 1234"  # Simulated LLM output
    if not llm_as_critic(system_prompt, raw_output):
        return "Blocked: LLM critic flagged the output."

    refined_output = adaptive_refine(raw_output)
    return f"Final output: {refined_output}"
