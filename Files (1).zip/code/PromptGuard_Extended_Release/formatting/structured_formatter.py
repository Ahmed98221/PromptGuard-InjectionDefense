import json

def to_structured_prompt(system_prompt: str, user_prompt: str) -> str:
    return json.dumps([
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ], indent=2)
